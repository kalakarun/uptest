#!/bin/sh

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
timestamp=$(date '+%Y-%m-%d %H:%M:%S %z')
printf '%s - ran successfully - Sample message\n' "$timestamp" >> "$script_dir/run.log"